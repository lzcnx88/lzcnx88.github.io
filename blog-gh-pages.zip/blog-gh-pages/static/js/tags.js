$(function(){
    $('.tagCloud').tagCloud();
});