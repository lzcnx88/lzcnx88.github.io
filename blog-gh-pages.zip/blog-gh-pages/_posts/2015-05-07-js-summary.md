---
layout: post
title: Javascript 总结
tags: Javascript script
categories: front-end
---

超级长图，小心流量。

![javascript] [javascript]

[javascript]:  {{"/JavaScriptMindMap.jpg" | prepend: site.imgrepo }}